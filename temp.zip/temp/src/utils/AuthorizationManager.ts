import urls from "../global/constants/UrlConstants";

export const homePageRedirection = (appAccess: String) => {
  if (appAccess == "user") {
    return urls.UserViewPath;
  } else {
    return urls.AdminViewPath;
  }
};
