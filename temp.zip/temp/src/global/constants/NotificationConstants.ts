import { StringConstants } from "./StringConstants";

class NotificationConstants extends StringConstants {
  GENERIC_ERROR = "An error has occurred";
  LOGGEDOUT = "You're logged out. Please login to continue.";
  LOGIN_ERROR = "Please enter valid email id and password";
}

let notifiers = new NotificationConstants();
export default notifiers;
