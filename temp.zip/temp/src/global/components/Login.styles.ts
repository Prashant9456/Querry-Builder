import {
  boldFont,
  centerItemFlex,
  getRelativeFontSize,
  inputLabelRequiredColor,
  mediumFont,
} from "../../utils/styles";

const loginStyles = {
  select: {
    borderRadius: "20px",
    border: "1px solid black",
    width: "100% !important",
  },
  error: {
    borderRadius: "8px",
    outline: "none",
    borderColor: "red !important",
    width: "100% !important",
  },
  label: { display: "flex", height: "20px", marginTop: "20px" },
  labelIcon: { color: "black" },
  labelText: {
    marginLeft: "6px",
    ...boldFont,
  },
  formCenter: {
    ...centerItemFlex,
  },
  textCenter: {
    ...mediumFont,
    margin: "20px 0px",
    fontSize: getRelativeFontSize(),
    textAlign: "center",
    cursor: "pointer",
    color: "#212121",
  },
  textRadious: {
    borderRadius: "100px",
  },
  getHeading: {
    ...boldFont,
    width: "82%",
    margin: "0 auto",
    fontSize: getRelativeFontSize(14),
    mt: 15,
  },
  star: {
    color: inputLabelRequiredColor,
    marginLeft: "2px",
    fontSize: getRelativeFontSize(5),
  },
  center: {
    ...boldFont,
    alignItem: "center",
  },
  getLoginScreen: {
    display: "grid",
    height: "100%",
  },
  innerGetLoginBox: { maxWidth: "100%", maxHeight: "100%" },
  forgetPasswordWrapper: {
    width: "100%",
    display: "flex",
    justifyContent: "flex-end",
  },
  signBtn: {
    width: "100%",
  },
  errorStyling: {
    paddingLeft: "10px",
  },
} as const;

export default loginStyles;
