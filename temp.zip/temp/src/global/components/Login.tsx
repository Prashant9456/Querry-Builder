import { useState } from "react";
import {
  Box,
  FormHelperText,
  Grid,
  IconButton,
  InputAdornment,
  Typography,
} from "@mui/material";
import loginStyles from "./Login.styles";
import history from "../../utils/history";
import strings from "../constants/StringConstants";
import { loginForm } from "./LoginTypesAndValidation";
import { homePageRedirection } from "../../utils/AuthorizationManager";
import { isTruthy, openErrorNotification } from "../../helpers/methods";
import notifiers from "../constants/NotificationConstants";

import CustomButton from "./CustomButton/CustomButton";
import CustomInput from "./CustomInput/CustomInput";

const Login = () => {
  const classes = loginStyles;
  const emailRegex = strings.regex;

  const [isLoading, setIsLoading] = useState(false);
  const [formFields, setFormFields] = useState(loginForm);
  const [showPassword, setShowPassword] = useState(false);

  const handleOnChangeInputField = (event: React.ChangeEvent<any>) => {
    setFormFields({
      ...formFields,
      [event.target.name]: {
        ...formFields[event.target.name],
        value: event.target.value,
      },
    });
  };

  const handleLogin = async () => {
    try {
      if (handleValidation()) {
        // setIsLoading(true);
        const email = formFields.email.value.toLowerCase();
        const password = formFields.password.value;
        const user = true;
        const appAccess = true;

        history.push(homePageRedirection(password));
      } else {
        setIsLoading(false);
      }
    } catch (error: any) {
      setIsLoading(false);
      openErrorNotification(
        isTruthy(error.errorMessage)
          ? error.errorMessage
          : notifiers.LOGIN_ERROR
      );
    }
  };

  const handleClickShowPassword = () => {
    setShowPassword(showPassword);
  };

  const handleKeypress = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === "Enter") {
      e.preventDefault();
      handleLogin();
    }
  };

  const handleMouseDownPassword = (
    event: React.MouseEvent<HTMLButtonElement>
  ) => {
    setShowPassword(!showPassword);
    event.preventDefault();
  };

  const handleValidation = () => {
    return true;
  };

  const getLoginScreen = () => {
    return (
      <Box sx={classes.getLoginScreen}>
        <Box sx={classes.innerGetLoginBox}>
          <Typography sx={classes.getHeading}>Sign In</Typography>
          <Grid container sx={classes.formCenter} spacing={2}>
            <Grid item xs={10} sm={10} md={10} lg={10} xl={10}>
              <Box sx={classes.label}>
                <Typography sx={classes.labelText} className="loginValidation">
                  Email
                </Typography>
                <Typography sx={classes.star}>*</Typography>
              </Box>
              <CustomInput
                placeHolder="Your email"
                id="email"
                type="email"
                name="email"
                value={formFields.email.value}
                onChange={handleOnChangeInputField}
                onKeyPress={handleKeypress}
                error={
                  !isTruthy(formFields.email.value) && formFields.email.error
                }
              />
              {!emailRegex.test(formFields.email.value) &&
                formFields.email.value.length > 0 && (
                  <FormHelperText error sx={classes.errorStyling}>
                    Please enter valid email id
                  </FormHelperText>
                )}
            </Grid>
            <Grid item xs={10} sm={10} md={10} lg={10} xl={10}>
              <Box sx={classes.label} borderColor="red">
                <Typography sx={classes.labelText}>Password </Typography>
                <Typography sx={classes.star}>*</Typography>
              </Box>
              <CustomInput
                sx={classes.textRadious}
                placeHolder="••••••••"
                id="password"
                type={showPassword ? "text" : "password"}
                name="password"
                value={formFields.password.value}
                onChange={handleOnChangeInputField}
                onKeyPress={handleKeypress}
                error={
                  !isTruthy(formFields.password.value) &&
                  formFields.password.error
                }
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton
                        aria-label="toggle password visibility"
                        onClick={handleClickShowPassword}
                        onMouseDown={handleMouseDownPassword}
                        edge="end"
                      ></IconButton>
                    </InputAdornment>
                  ),
                }}
              />
            </Grid>
            <Grid item xs={10} sm={10} md={10} lg={10} xl={10}>
              <Box sx={classes.forgetPasswordWrapper}></Box>
              <Box marginTop={"10px"} width={"100%"}>
                <CustomButton
                  label="Sign In"
                  onClick={handleLogin}
                  loading={isLoading}
                  customClasses={classes.signBtn}
                />
              </Box>
            </Grid>
          </Grid>
        </Box>
      </Box>
    );
  };

  return (
    <Box
      style={{
        height: "100%",
        width: "100%",
      }}
      marginTop={{ xs: "50px", md: "0" }}
    >
      {getLoginScreen()}
    </Box>
  );
};

export default Login;
