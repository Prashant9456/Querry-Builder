import React from "react";

const user = () => {
  return <div>user</div>;
};

export default user;
