import { Box } from "@mui/system";
import CustomPaper from "../../global/components/CustomPaper/CustomPaper";
import landingPageStyles from "./LandingPage.styles";
import LoginImage from "../../assets/images/Login.png";
import strings from "../../global/constants/StringConstants";
import Login from "../../global/components/Login";
import { Container, Grid, Typography } from "@mui/material";
import urls from "../../global/constants/UrlConstants";
import history from "../../utils/history";
interface CustomProps {
  location?: Location;
}
const LandingPage = (props: CustomProps) => {
  const classes = landingPageStyles;
  const staticImageComponent = () => {
    return (
      <Box sx={classes.boxImage}>
        <CustomPaper className={classes.boxImage}>
          <img
            src={LoginImage}
            alt="landing image"
            style={{ width: "100%", borderRadius: "13px " }}
          />
        </CustomPaper>
      </Box>
    );
  };
  const getComponentBasedOnURL = () => {
    const location = props.location?.pathname?.split("/")[1].toLowerCase();
    switch (location) {
      case strings.LOGIN: {
        return <Login />;
      }

      default: {
        return <Login />;
      }
    }
  };
  const getYear = () => {
    return new Date().getFullYear();
  };
  const getFooter = () => {
    return (
      <Box sx={classes.footer}>
        <Typography sx={classes.footerTypo}>
          &copy; {getYear()} SoftSages Technology. All Rights Reserved
        </Typography>
      </Box>
    );
  };

  const getLandingPage = () => {
    return (
      <Box>
        <Container>
          <Grid container sx={classes.mainGrid}>
            <Grid item xs={12} sm={12} md={6} lg={6} xl={6}>
              <Box style={{ height: "100%", display: "flex" }}>
                <CustomPaper className={classes.radiusRight}>
                  {getComponentBasedOnURL()}
                </CustomPaper>
              </Box>
            </Grid>
            <Grid item xs={12} sm={12} md={6} lg={6} xl={6}>
              {staticImageComponent()}
            </Grid>
          </Grid>
        </Container>

        {getFooter()}
      </Box>
    );
  };

  return getLandingPage();
};

export default LandingPage;
