import { Box, Grid, Typography } from "@mui/material";
import React, { useState } from "react";
import { CustomButton } from "../../global/components";
import CustomDialog from "../../global/components/CustomDialog/CustomDialog";
import AdminStyle from "./Admin.style";
import history from "../../utils/history";
import urls from "../../global/constants/UrlConstants";
import CustomInput from "../../global/components/CustomInput/CustomInput";
import { insertschemaField } from "./AddTable/AddTableValidation";
const Admin = () => {
  const classes = AdminStyle;
  const [tableData, setTableData] = useState<any>(insertschemaField());
  const [schemaData, setSchemaData] = useState<any>([
    {
      tableName: {
        name: "",
      },
    },
  ]);
  const handleState = (event: React.ChangeEvent<any>) => {
    sessionStorage.clear();
    setTableData({
      ...tableData,
      [event.target.name]: {
        ...tableData[event.target.name],
        value: event.target.value,
      },
    });
  };
  console.log(schemaData);
  const ShowData = () => {
    return (
      <>
        {schemaData.map((item: any, index: number) => {
          <>
            <Box>
              <Typography sx={classes.mediumFonts}>
                {"item.tableName.id"}
              </Typography>
            </Box>
            <Box>
              <Typography sx={classes.mediumFonts}>
                {item.tableName.phoneno}
              </Typography>
            </Box>
            <Box>
              <Typography sx={classes.mediumFonts}>
                {item.tableName.name}
              </Typography>
            </Box>
          </>;
        })}
        {console.log("hello")}
      </>
    );
  };
  const data = sessionStorage.getItem("schemaname");
  const CreateTable = () => {
    const handleCreateTable = () => {
      if (tableData.tableschemaname) {
        sessionStorage.setItem("schemaname", tableData.tableschemaname.value);
        return history.push(urls.addTable);
      }
    };
    return (
      <>
        <Box>
          <Grid container>
            <Grid item xs={12} sm={6} md={6} lg={6} xl={6}>
              <Box ml={5} mr={5} mt={3}>
                <CustomInput
                  required
                  label="Table Name"
                  varient="standard"
                  name="tableschemaname"
                  onChange={handleState}
                  value={data}
                  InputProps={{ disableUnderline: true }}
                />
              </Box>
            </Grid>
          </Grid>
          <CustomButton onClick={handleCreateTable} label="CreateTable" />
        </Box>
      </>
    );
  };
  const AdminData = () => {
    return (
      <>
        {CreateTable()}
        {ShowData()}
      </>
    );
  };

  return AdminData();
};

export default Admin;
