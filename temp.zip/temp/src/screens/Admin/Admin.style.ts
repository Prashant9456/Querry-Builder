import {
  boldFont,
  centerItemFlex,
  customButton1Style,
  getRelativeFontSize,
  inputLabelRequiredColor,
  mediumFont,
  regularFont,
} from "../../utils/styles";

const AdminStyle = {
  modalTitle: {
    ...boldFont,
    fontSize: getRelativeFontSize(13),
    textAlign: "center",
    background: "#F5F5F5",
  },
  nameField: {
    ...boldFont,
    color: "#0D3057",
    "& .MuiFormLabel-asterisk": {
      color: inputLabelRequiredColor,
    },
  },
  textField: {
    "& fieldset": { border: "none" },
    width: "100%",
    borderRadius: "10px",
    background: "#ffffff",
    "& .MuiInputBase-input": {
      position: "relative",
      padding: "12px 12px",
      "&::placeholder": {
        ...mediumFont,
      },
    },
    "& .MuiOutlinedInput-root": {
      borderRadius: "10px",
    },
  },
  mediumFonts: {
    ...mediumFont,
    fontSize: getRelativeFontSize(5),
  },
  fontText: {
    ...regularFont,
  },
  dialogFooter: {
    ...centerItemFlex,
    gap: "10px",
    paddingBottom: "20px",
    width: "100%",
    display: "flex",
    justifyContent: "center",
    "& button": {
      width: "120px",
    },
  },
  cancelButtonStyle: {
    color: "#212121 !important",
    backgroundColor: "#FFFFFF",
    border: "1px solid #E7E7E7",
    borderRadius: "10px",
    "&:hover": {
      background: "none",
    },
  },
  centerItemFlex: {
    ...centerItemFlex,
    flexDirection: "column",
  },
  saveButton: {
    marginTop: "20px",
    marginBottom: "30px",
    justifyContent: "center",
  },
  customAddHeader: { justifyContent: "end" },
  customButton1: {
    ...customButton1Style,
  },
} as const;
export default AdminStyle;
