export const inserttableField = () => {
  return {
    columnData: [
      {
        name: "",
        type: "",
      },
    ],
  };
};

export const insertschemaField = () => {
  return {};
};
