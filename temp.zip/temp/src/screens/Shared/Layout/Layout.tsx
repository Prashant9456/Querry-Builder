import { Box } from "@mui/system";
import { useState } from "react";
import { Switch } from "react-router-dom";
import PrivateRoute from "../../../global/components/PrivateRoute/PrivateRoute";
import urls from "../../../global/constants/UrlConstants";
import User from "../../User/user";
import LandingPage from "../../LandingPage/LandingPage";

import Loading from "../Loading";
import layoutStyles from "./Layout.styles";
import Admin from "../../Admin/Admin";
import AddTable from "../../Admin/AddTable/AddTable";

const Layout = () => {
  const classes = layoutStyles;
  const [isLoading, setIsLoading] = useState(false);

  const getContent = () => {
    return (
      <Box sx={classes.content}>
        <Switch>
          <PrivateRoute
            exact
            isLoggedIn={true}
            path={urls.AdminViewPath}
            component={Admin}
          />
          <PrivateRoute
            exact
            isLoggedIn={true}
            path={urls.UserViewPath}
            component={User}
          />
          <PrivateRoute
            exact
            isLoggedIn={true}
            path={urls.addTable}
            component={AddTable}
          />
        </Switch>
      </Box>
    );
  };

  const getLayout = () => {
    return getContent();
  };

  return getLayout();
};

export default Layout;
