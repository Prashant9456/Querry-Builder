import { Box } from "@mui/system";

const EmptyBox = () => {
  return <Box style={{ height: "55px" }}></Box>;
};

export default EmptyBox;
