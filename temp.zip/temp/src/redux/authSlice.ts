import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { RootState } from "../utils/store";

export interface AuthState {
  authenticated: boolean;
  accessToken: string;
  refreshToken: string;
  userIdToken: string;
  loading: boolean;
}

const initialState: AuthState = {
  authenticated: true,
  accessToken: "",
  refreshToken: "",
  userIdToken: "",
  loading: false,
};

export const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    login: (
      state,
      action: PayloadAction<{
        authenticated: boolean;
        accessToken: string;
        userIdToken: string;
        refreshToken: string;
      }>
    ) => {
      state.authenticated = action.payload.authenticated;
      state.accessToken = action.payload.accessToken;
      state.userIdToken = action.payload.userIdToken;
      state.refreshToken = action.payload.refreshToken;
    },
    updateTokens: (
      state,
      action: PayloadAction<{
        userIdToken: string;
        refreshToken: string;
      }>
    ) => {
      state.userIdToken = action.payload.userIdToken;
      state.refreshToken = action.payload.refreshToken;
    },
    addLoading: (state, action: PayloadAction<boolean>) => {
      state.loading = action.payload;
    },
    logOutAction: (state, action: {}) => {
      state.authenticated = false;
      state.loading = false;
      state.userIdToken = "";
      state.refreshToken = "";
    },
  },
});

export const { login, updateTokens, logOutAction, addLoading } =
  authSlice.actions;

export const selectAuthenticated = (state: RootState) =>
  state.auth.authenticated;
export const selectAccessToken = (state: RootState) => state.auth.accessToken;
export const selectUserIdToken = (state: RootState) => state.auth.userIdToken;
export const selectRefreshToken = (state: RootState) => state.auth.refreshToken;
export const selectLoading = (state: RootState) => state.auth.loading;

export default authSlice.reducer;
