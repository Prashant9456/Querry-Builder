import { CSSProperties } from "@mui/styles";

export interface OTPInputProps {
  length: number;
  onChangeOTP: (otp: string) => any;

  autoFocus?: boolean;
  isNumberInput?: boolean;
  disabled?: boolean;

  style?: CSSProperties;
  className?: string;

  inputStyle?: CSSProperties;
  inputClassName?: string;
}
export interface LoginFields {
  [key: string]: {
    value: string;
    error: any;
  };
}

export interface ForgotPasswordFields {
  [key: string]: {
    value: string;
    error: any;
  };
}

export interface RegistrationFeild {
  [key: string]: {
    value: string;
    error: string;
  };
}

export interface LoginFormFields {
  [key: string]: {
    value: string;
    label: string;
    type: string;
    icon?: JSX.Element;
  };
}

export interface SwitchButtonProps {
  text: string;
  onClick: Function;
}
