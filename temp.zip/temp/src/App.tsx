import history from "./utils/history";
import { Router, Switch, Route } from "react-router-dom";
import urls from "./global/constants/UrlConstants";
import withClearCache from "./ClearCache";
import Box from "@mui/system/Box";

import PageNotFound from "./screens/PageNotFound/PageNotFound";
import Notifications from "./utils/notifications";
import LandingPage from "./screens/LandingPage/LandingPage";
import Layout from "./screens/Shared/Layout/Layout";


const App = () => {
  return <ClearCacheComponent />;
};

const MainApp = () => {
  return (
    <Box>
      <Router history={history}>
        <Switch>
          <Route exact path={urls.landingViewPath} component={LandingPage} />
          {/* <PrivateRoute
            exact
            isLoggedIn={authenticated}
            path={urls.paymentViewPath}
            component={Payment}
          /> */}

          <Layout />
          <Route path={""} component={PageNotFound} />
        </Switch>
      </Router>
      <Notifications />
    </Box>
  );
};

const ClearCacheComponent = withClearCache(MainApp);

export default App;
